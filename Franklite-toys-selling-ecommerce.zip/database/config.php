<?php
define('SITE_NAME', 'Franklite Toys');
define('BASE_URL', 'http://localhost/Franklite-toys-selling-ecommerce/');
define('ADMIN_URL', BASE_URL . '/admin');
?>