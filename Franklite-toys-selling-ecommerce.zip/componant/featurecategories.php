 <div class="featured-categories-area pb-100">
            <div class="container">
                <div class="row" data-cues="slideInUp" data-group="FeaturedCategoriesContent">
                    <div class="col-sm-6">
                        <div class="featured-category-item position-relative">
                            <img src="assets/images/categories/category17.jpg" alt="featured-categories-image">
                            <h3 class="mb-0 two">
                                New Arrival
                            </h3>
                            <a href="shop-grid.html" class="link-btn d-block"></a>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="featured-category-item position-relative">
                            <img src="assets/images/categories/category18.jpg" alt="featured-categories-image">
                            <h3 class="mb-0 two">
                                Clearance
                            </h3>
                            <a href="shop-grid.html" class="link-btn d-block"></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>