<div class="categories-area bg-image2 pt-125 pb-100">
            <div class="container">
                <div class="row justify-content-center" data-cues="slideInUp" data-group="categoriesContent">
                    <div class="col-lg-2 col-6 col-sm-4 col-md-3">
                        <div class="category-box text-center">
                            <a href="shop-grid.html" class="image d-block text-center">
                                <img src="assets/images/categories/category7.png" alt="category-image">
                            </a>
                            <h3 class="mb-0">
                                <a href="shop-grid.html">
                                    Kids Dress
                                </a>
                            </h3>
                        </div>
                    </div>
                    <div class="col-lg-2 col-6 col-sm-4 col-md-3">
                        <div class="category-box text-center">
                            <a href="shop-grid.html" class="image d-block text-center">
                                <img src="assets/images/categories/category8.png" alt="category-image">
                            </a>
                            <h3 class="mb-0">
                                <a href="shop-grid.html">
                                    Accessories
                                </a>
                            </h3>
                        </div>
                    </div>
                    <div class="col-lg-2 col-6 col-sm-4 col-md-3">
                        <div class="category-box text-center">
                            <a href="shop-grid.html" class="image d-block text-center">
                                <img src="assets/images/categories/category9.png" alt="category-image">
                            </a>
                            <h3 class="mb-0">
                                <a href="shop-grid.html">
                                    Kids Doll
                                </a>
                            </h3>
                        </div>
                    </div>
                    <div class="col-lg-2 col-6 col-sm-4 col-md-3">
                        <div class="category-box text-center">
                            <a href="shop-grid.html" class="image d-block text-center">
                                <img src="assets/images/categories/category10.png" alt="category-image">
                            </a>
                            <h3 class="mb-0">
                                <a href="shop-grid.html">
                                    Kids Toys
                                </a>
                            </h3>
                        </div>
                    </div>
                    <div class="col-lg-2 col-6 col-sm-4 col-md-3">
                        <div class="category-box text-center">
                            <a href="shop-grid.html" class="image d-block text-center">
                                <img src="assets/images/categories/category11.png" alt="category-image">
                            </a>
                            <h3 class="mb-0">
                                <a href="shop-grid.html">
                                    Kids Diaper
                                </a>
                            </h3>
                        </div>
                    </div>
                    <div class="col-lg-2 col-6 col-sm-4 col-md-3">
                        <div class="category-box text-center">
                            <a href="shop-grid.html" class="image d-block text-center">
                                <img src="assets/images/categories/category12.png" alt="category-image">
                            </a>
                            <h3 class="mb-0">
                                <a href="shop-grid.html">
                                    Cosmetics
                                </a>
                            </h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>