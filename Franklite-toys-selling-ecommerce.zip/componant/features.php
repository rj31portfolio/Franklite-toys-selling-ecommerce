   
        <div class="features-area padding-top pb-100">
            <div class="container">
                <div class="row justify-content-center" data-cues="slideInUp" data-group="featuresContent">
                    <div class="col-lg-4 col-sm-6">
                        <div class="feature-item position-relative">
                            <img src="assets/images/icons/icon6.png" alt="icon">
                            <h3>
                                Free Same-Day Delivery
                            </h3>
                            <span class="d-block">
                                Over $50 or more Order
                            </span>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6">
                        <div class="feature-item position-relative">
                            <img src="assets/images/icons/icon7.png" alt="icon">
                            <h3>
                                Moneback Garuntee
                            </h3>
                            <span class="d-block">
                                Within 30 days return
                            </span>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6">
                        <div class="feature-item position-relative">
                            <img src="assets/images/icons/icon8.png" alt="icon">
                            <h3>
                                24/7 Support
                            </h3>
                            <span class="d-block">
                                With our dedicated team
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
       