<div class="mega-kids-banner-area">
    <div class="container">
        <div class="row align-items-center" data-cues="slideInUp" data-group="bannerContent">
            <div class="col-lg-6 col-md-12">
                <div class="mega-kids-banner-content">
                    <img src="<?= BASE_URL ?>assets/images/banner/banner8.png" alt="banner-content">
                </div>
            </div>
            <div class="col-lg-6 col-md-12">
                <div class="mega-kids-banner-image text-center">
                    <img src="<?= BASE_URL ?>assets/images/banner/banner9.png" alt="banner-image">
                </div>
            </div>
        </div>
    </div>
</div>